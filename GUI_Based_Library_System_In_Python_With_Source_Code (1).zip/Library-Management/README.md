# Library Management System in Python
Library Management System in python(tkinter) GUI based project in python using tkinter and Sqlite DB.
Functionalities provided by this project includes:
- Adding books
- Sorting books
- Searching books
- Adding members
- Issuing books
- Summary calculation
